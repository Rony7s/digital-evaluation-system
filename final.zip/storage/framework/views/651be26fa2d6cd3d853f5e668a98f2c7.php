<div class="p-6 bg-white rounded shadow">
    <h1 class="text-2xl font-bold mb-4">Exam Results</h1>
    <p class="mb-2">Exam Code: <?php echo e($examCode); ?></p>
    <p class="mb-4">Exam Name: <?php echo e($examName); ?></p>

    <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border px-4 py-2">#</th>
                <th class="border px-4 py-2">Student ID</th>
                <th class="border px-4 py-2">Email</th>
                <th class="border px-4 py-2">Score</th>
                <th class="border px-4 py-2">Total</th>
                <th class="border px-4 py-2">Comment</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($index + 1); ?></td>
                    <td class="border px-4 py-2"><?php echo e($result['student_id']); ?></td>
                    <td class="border px-4 py-2"><?php echo e($result['student_email']); ?></td>
                    <td class="border px-4 py-2 font-semibold"><?php echo e($result['score']); ?></td>
                    <td class="border px-4 py-2"><?php echo e($result['total']); ?></td>
                    <td class="border px-4 py-2"><?php echo e($result['comment']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-gray-500 py-4">No submissions yet.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
    
    
    <h1 style="margin:10px;">Summary</h1>
    <table class="table-auto   border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border px-4 py-2">NO</th>
                <th class="border px-4 py-2">A</th>
                <th class="border px-4 py-2">B</th>
                <th class="border px-4 py-2">C</th>
                <th class="border px-4 py-2">D</th>
                <th class="border px-4 py-2">X</th>
                <th class="border px-4 py-2">R</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $analyzedResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($index+1); ?></td>
                    
                      
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'A'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e($result['A']); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e($result['A']); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'B'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e($result['B']); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e($result['B']); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'C'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e($result['C']); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e($result['C']); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'D'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e($result['D']); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e($result['D']); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="border px-4 py-2"><?php echo e($result['X']); ?></td>
                    <td class="border px-4 py-2"><?php echo e($result['R']); ?></td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-gray-500 py-4">No submissions yet.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    
    <table class="table-auto   border-collapse border border-gray-300">
        <h1 style="margin:10px;">Parsentage</h1>
        <thead>
            <tr class="bg-gray-200">
                <th class="border px-4 py-2">NO</th>
                <th class="border px-4 py-2">A</th>
                <th class="border px-4 py-2">B</th>
                <th class="border px-4 py-2">C</th>
                <th class="border px-4 py-2">D</th>
                <th class="border px-4 py-2">X</th>
                <th class="border px-4 py-2">R</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $analyzedResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($index+1); ?></td>
                      
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'A'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e(round(($result['A'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e(round(($result['A'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'B'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e(round(($result['B'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e(round(($result['B'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'C'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e(round(($result['C'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e(round(($result['C'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($result['R'] === 'D'): ?>
                        <td class="border px-4 py-2 bg-green-200"><?php echo e(round(($result['D'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php else: ?>
                        <td class="border px-4 py-2"><?php echo e(round(($result['D'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="border px-4 py-2"><?php echo e(round(($result['X'] / ($result['A']+$result['B']+$result['C']+$result['D']+$result['X'])) * 100, 2) . '%'); ?></td>

                    <td class="border px-4 py-2"><?php echo e($result['R']); ?></td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-gray-500 py-4">No submissions yet.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
    <div class="mt-4">
        <a href="<?php echo e(route('exams.index')); ?>" class="text-blue-500 hover:underline">Back to Exams</a>
    </div>
</div>
<?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/exams/exam-result.blade.php ENDPATH**/ ?>