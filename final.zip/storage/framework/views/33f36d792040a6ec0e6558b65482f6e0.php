<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 42" <?php echo e($attributes); ?>>
    <image
        href="<?php echo e(asset('images/logo.jpg')); ?>"
        x="0" y="0" width="40" height="42" />
</svg>
<?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>