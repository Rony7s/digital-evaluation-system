<div class="relative mb-6 w-full">
    <h1 class="text-2xl font-bold"><?php echo e(__('Questions')); ?></h1>
    <p class="text-lg text-gray-600 mb-6"><?php echo e(__('Manage your Questions Bank')); ?></p>
    <hr class="mb-4 border-gray-300" />

    <div class="flex items-center justify-between">
        <a href="<?php echo e(route('questions.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i>
            <?php echo e(__('Add Question')); ?>

        </a>

        <input
            type="text"
            wire:model.debounce.500ms="search"
            placeholder="<?php echo e(__('Search Questions')); ?>"
            class="border border-gray-300 rounded px-3 py-2 w-full max-w-xs"
            id="searchInput"
        />
    </div>

    <table class="mt-4 w-full border-collapse" id="questionsTable">
        <thead>
            <tr class="bg-gray-100">
                <th class="border px-4 py-2"><?php echo e(__('No')); ?></th>
                <th class="border px-4 py-2"><?php echo e(__('Question Type')); ?></th>
                <th class="border px-4 py-2"><?php echo e(__('Question Text')); ?></th>
                <th class="border px-4 py-2"><?php echo e(__('Question Comment')); ?></th>
                <th class="border px-4 py-2"><?php echo e(__('Actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($question->id); ?></td>
                <td class="border px-4 py-2"><?php echo e($question->questionType); ?></td>
                <td class="border px-4 py-2"><?php echo e($question->questionText); ?></td>
                <td class="border px-4 py-2"><?php echo e($question->comment ?? '-'); ?></td>
                    <td class="border px-4 py-2">

                        <a href="<?php echo e(route('questions.edit', $question->id)); ?>" class="text-blue-600 hover:underline">
                            <?php echo e(__('Edit')); ?>

                        </a>
                        <button wire:click="deleteQuestion(<?php echo e($question->id); ?>)" wire:confirm="Are you sure Delete it?" class="text-red-600 hover:underline ml-2">
                            <?php echo e(__('Delete')); ?>

                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
</div>

<script>
  document.getElementById('searchInput').addEventListener('input', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#questionsTable tbody tr');

    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      if(text.includes(filter)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
</script><?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/questions/question-index.blade.php ENDPATH**/ ?>