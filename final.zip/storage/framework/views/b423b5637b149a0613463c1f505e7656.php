<div class="relative mb-6 w-full">
    <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['size' => 'xl','level' => '1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'xl','level' => '1']); ?>
        <?php echo e($questionId ? __('Edit Question') : __('Question Create')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['size' => 'lg','class' => 'mb-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'lg','class' => 'mb-6']); ?>
        <?php echo e($questionId ? __('Update existing question') : __('Add Question here')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc481942d30cc0ab06077963cf20a45e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc481942d30cc0ab06077963cf20a45e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::separator','data' => ['variant' => 'subtle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'subtle']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc481942d30cc0ab06077963cf20a45e8)): ?>
<?php $attributes = $__attributesOriginalc481942d30cc0ab06077963cf20a45e8; ?>
<?php unset($__attributesOriginalc481942d30cc0ab06077963cf20a45e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc481942d30cc0ab06077963cf20a45e8)): ?>
<?php $component = $__componentOriginalc481942d30cc0ab06077963cf20a45e8; ?>
<?php unset($__componentOriginalc481942d30cc0ab06077963cf20a45e8); ?>
<?php endif; ?>

    <!-- Flash message -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="mb-4 p-3 rounded-lg bg-green-100 text-green-800 border border-green-300">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Form Container -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
        <form wire:submit.prevent="submit" class="space-y-6">

            <!-- Question Type -->
            <div>
                <label for="questionType" class="block text-sm font-medium text-gray-700 mb-1">Question Type</label>
                <div class="relative">
                    <select id="questionType" wire:model="questionType"
                        class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
                        focus:ring-2 focus:ring-blue-200 focus:border-blue-500 appearance-none
                        bg-[url('data:image/svg+xml;base64,...')] bg-no-repeat bg-[right_1rem_center] bg-[length:1.5rem]">
                        <option value="">-- Select Type --</option>
                        <option value="public">Public</option>
                        <option value="private">Private</option>
                    </select>
                    <i class="fas fa-chevron-down absolute right-4 top-3.5 text-gray-400 pointer-events-none"></i>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['questionType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Question Text -->
            <div>
                <label for="questionText" class="block text-sm font-medium text-gray-700 mb-1">Question Text</label>
                <input type="text" id="questionText" wire:model="questionText" placeholder="Enter your question"
                    class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
                    focus:ring-2 focus:ring-blue-200 focus:border-blue-500">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['questionText'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Options -->
            <div class="pt-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Options</label>
                <div class="space-y-3">

                    <div class="option-input flex items-center border border-gray-300 rounded-lg focus-within:border-blue-500">
                        <div class="bg-gray-100 text-gray-500 px-4 py-2.5 rounded-l-lg border-r border-gray-300">A</div>
                        <input type="text" wire:model="options1" placeholder="Option 1" class="w-full py-2.5 px-4 rounded-r-lg focus:outline-none">
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["options1"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="option-input flex items-center border border-gray-300 rounded-lg focus-within:border-blue-500">
                        <div class="bg-gray-100 text-gray-500 px-4 py-2.5 rounded-l-lg border-r border-gray-300">B</div>
                        <input type="text" wire:model="options2" placeholder="Option 2" class="w-full py-2.5 px-4 rounded-r-lg focus:outline-none">
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["options2"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="option-input flex items-center border border-gray-300 rounded-lg focus-within:border-blue-500">
                        <div class="bg-gray-100 text-gray-500 px-4 py-2.5 rounded-l-lg border-r border-gray-300">C</div>
                        <input type="text" wire:model="options3" placeholder="Option 3" class="w-full py-2.5 px-4 rounded-r-lg focus:outline-none">
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["options3"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="option-input flex items-center border border-gray-300 rounded-lg focus-within:border-blue-500">
                        <div class="bg-gray-100 text-gray-500 px-4 py-2.5 rounded-l-lg border-r border-gray-300">D</div>
                        <input type="text" wire:model="options4" placeholder="Option 4" class="w-full py-2.5 px-4 rounded-r-lg focus:outline-none">
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["options4"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                </div>
            </div>

            <!-- Right Answer -->
            <div class="pt-2">
                <label class="block text-sm font-medium text-gray-700 mb-3">Right Answer</label>
                <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">

                    <div class="flex items-center">
                        <input type="radio" id="answer1" value="a" wire:model="rightAnswer"
                            class="h-5 w-5 text-blue-600 border-gray-300 focus:ring-blue-500">
                        <label for="answer1" class="ml-2 text-gray-700">Option A</label>
                    </div>

                    <div class="flex items-center">
                        <input type="radio" id="answer2" value="b" wire:model="rightAnswer"
                            class="h-5 w-5 text-blue-600 border-gray-300 focus:ring-blue-500">
                        <label for="answer2" class="ml-2 text-gray-700">Option B</label>
                    </div>

                    <div class="flex items-center">
                        <input type="radio" id="answer3" value="c" wire:model="rightAnswer"
                            class="h-5 w-5 text-blue-600 border-gray-300 focus:ring-blue-500">
                        <label for="answer3" class="ml-2 text-gray-700">Option C</label>
                    </div>

                    <div class="flex items-center">
                        <input type="radio" id="answer4" value="d" wire:model="rightAnswer"
                            class="h-5 w-5 text-blue-600 border-gray-300 focus:ring-blue-500">
                        <label for="answer4" class="ml-2 text-gray-700">Option D</label>
                    </div>

                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['rightAnswer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>



            <!-- Comment -->
            <div>
                <label for="comment" class="block text-sm font-medium text-gray-700 mb-1">Comment (Optional)</label>
                <textarea id="comment" wire:model="comment" rows="3"
                    class="w-full py-2.5 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-200 focus:border-blue-500"
                    placeholder="Optional explanation or note..."></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Submit Button -->
            <div class="pt-6">
                <button type="submit"
                    class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 
                    transition flex items-center justify-center w-full sm:w-auto">
                    <i class="fas fa-save mr-2"></i>
                    <?php echo e($questionId ? 'Update Question' : 'Add Question'); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/questions/question-edit.blade.php ENDPATH**/ ?>