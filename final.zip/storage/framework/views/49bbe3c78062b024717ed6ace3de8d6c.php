<div class="relative mb-6 w-full">
  <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['size' => 'xl','level' => '1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'xl','level' => '1']); ?><?php echo e(__('Create Exam')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['size' => 'lg','class' => 'mb-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'lg','class' => 'mb-6']); ?><?php echo e(__('Fill in exam details below')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginalc481942d30cc0ab06077963cf20a45e8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc481942d30cc0ab06077963cf20a45e8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::separator','data' => ['variant' => 'subtle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'subtle']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc481942d30cc0ab06077963cf20a45e8)): ?>
<?php $attributes = $__attributesOriginalc481942d30cc0ab06077963cf20a45e8; ?>
<?php unset($__attributesOriginalc481942d30cc0ab06077963cf20a45e8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc481942d30cc0ab06077963cf20a45e8)): ?>
<?php $component = $__componentOriginalc481942d30cc0ab06077963cf20a45e8; ?>
<?php unset($__componentOriginalc481942d30cc0ab06077963cf20a45e8); ?>
<?php endif; ?>

  <!-- Flash message -->
  <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div class="mb-4 p-3 rounded-lg bg-green-100 text-green-800 border border-green-300">
      <?php echo e(session('message')); ?>

    </div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <!-- Form Container -->
  <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
    <form wire:submit.prevent="submit" class="space-y-6">

      <!-- Exam Code -->
      <div>
        <label for="examCode" class="block text-sm font-medium text-gray-700 mb-1">Exam Code</label>
        <input type="text" id="examCode" wire:model.lazy="examCode" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['examCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Exam Name -->
      <div>
        <label for="examName" class="block text-sm font-medium text-gray-700 mb-1">Exam Name</label>
        <input type="text" id="examName" wire:model.lazy="examName" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['examName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Teacher Password -->
      <div>
        <label for="teacherPass" class="block text-sm font-medium text-gray-700 mb-1">Teacher Password</label>
        <input type="password" id="teacherPass" wire:model.lazy="teacherPass" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['teacherPass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Student Password -->
      <div>
        <label for="studentPass" class="block text-sm font-medium text-gray-700 mb-1">Student Password</label>
        <input type="password" id="studentPass" wire:model.lazy="studentPass" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['studentPass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Exam Start -->
      <div>
        <label for="examStart" class="block text-sm font-medium text-gray-700 mb-1">Exam Start Date & Time</label>
        <input type="datetime-local" id="examStart" wire:model.lazy="examStart" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['examStart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Duration -->
      <div>
        <label for="duration" class="block text-sm font-medium text-gray-700 mb-1">Duration (minutes)</label>
        <input type="number" id="duration" min="1" wire:model.lazy="duration" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Question IDs -->
      <div>
        <label for="questionsIds" class="block text-sm font-medium text-gray-700 mb-1">Question IDs (comma separated)</label>
        <input type="text" id="questionsIds" wire:model.lazy="questionsIdsString" placeholder="e.g. 1,33,22,34"
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['questionsIds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Comment -->
      <div>
        <label for="comment" class="block text-sm font-medium text-gray-700 mb-1">Comment (optional)</label>
        <textarea id="comment" wire:model.lazy="comment" rows="3" 
          class="w-full py-2.5 px-4 border border-gray-300 rounded-lg 
          focus:ring-2 focus:ring-blue-200 focus:border-blue-500" 
          placeholder="Optional notes or instructions..."></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <!-- Submit Button -->
      <div>
        <button type="submit"
          class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 
          focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 
          transition w-full sm:w-auto">
          Create Exam
        </button>
      </div>

    </form>
  </div>
</div>
<?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/exams/exam-create.blade.php ENDPATH**/ ?>