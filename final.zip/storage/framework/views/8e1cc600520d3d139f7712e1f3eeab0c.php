<div>
    <h1>This is Quiz Section</h1>
</div><?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/components/quiz/create.blade.php ENDPATH**/ ?>