<div class="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow">
    <h2 class="text-xl font-semibold mb-4">Result Quiz</h2>

    <!--[if BLOCK]><![endif]--><?php if($error): ?>
        <div class="bg-red-100 text-red-700 p-2 mb-3 rounded">
            <?php echo e($error); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="bg-green-100 text-green-700 p-2 mb-3 rounded">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="resultQuiz">
        <div class="mb-4">
            <label for="examCode" class="block font-medium">Exam Code</label>
            <input type="text" id="examCode" wire:model="examCode" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label for="studentPass" class="block font-medium">Student Password</label>
            <input type="password" id="studentPass" wire:model="studentPass" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label for="studentId" class="block font-medium">Student ID</label>
            <input type="text" id="studentId" wire:model="studentId" class="w-full border p-2 rounded" required>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Sesult</button>
    </form>
</div><?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/quiz/result.blade.php ENDPATH**/ ?>