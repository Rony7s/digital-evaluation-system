<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 42" <?php echo e($attributes); ?>>
    <image
        href="https://scontent.fdac181-1.fna.fbcdn.net/v/t39.30808-1/457355434_368545896299567_7164814728011034816_n.jpg?stp=dst-jpg_s200x200_tt6&_nc_cat=103&ccb=1-7&_nc_sid=2d3e12&_nc_eui2=AeHW8AjZC9qsHaFLH4hH4sD4HqFDJbaUJygeoUMltpQnKMOl8mBeS9u9I454GIrDYnvVcptvEpDrrlQhK4YR1TQk&_nc_ohc=cUlZ34YKSWwQ7kNvwG2V9SS&_nc_oc=AdkOLYAIBH47YAdrmBlQKRPMKv4XVyk7iQEV-6j5RhhIoWBEJy5fH4EQlTUV2DS__Gk&_nc_zt=24&_nc_ht=scontent.fdac181-1.fna&_nc_gid=RNc9cCYDx96-ffeMcc2ewg&oh=00_AfTFICEMPePM07Pr44CTZ41V4Eq9BZoA2azC5arOisPQZw&oe=6873337E"
        x="0" y="0" width="40" height="42" />
</svg>
<?php /**PATH D:\Laravel\demo-app\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>