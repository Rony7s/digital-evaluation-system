<div class="relative mb-6 w-full">
    <h1 class="text-2xl font-bold"><?php echo e(__('Exams')); ?></h1>
    <p class="text-lg text-gray-600 mb-6"><?php echo e(__('Manage your Exams')); ?></p>
    <hr class="mb-4 border-gray-300" />

    <div class="flex items-center justify-between mb-4">
        <a href="<?php echo e(route('exam.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus mr-2"></i>
            <?php echo e(__('Create new Exam')); ?>

        </a>

        <input
            type="text"
            wire:model.debounce.500ms="search"
            placeholder="<?php echo e(__('Search Exams')); ?>"
            class="border border-gray-300 rounded px-3 py-2 w-full max-w-xs"
            id="searchInput"
        />
    </div>

    <table class="mt-4 w-full border-collapse" id="questionsTable">
        <thead>
            <tr class="bg-gray-100 text-left">
                <th class="border px-4 py-2">No</th>
                <th class="border px-4 py-2">Exam Code</th>
                <th class="border px-4 py-2">Exam Name</th>
                
                <th class="border px-4 py-2">Teacher Password</th>
                <th class="border px-4 py-2">Student Password</th>
                <th class="border px-4 py-2">Exam Start</th>
                <th class="border px-4 py-2">Duration</th>
                <th class="border px-4 py-2">Questions IDs</th>
                <th class="border px-4 py-2">Comment</th>
                <th class="border px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($index + 1); ?></td>
                    <td class="border px-4 py-2"><?php echo e($exam->examCode); ?></td>
                    <td class="border px-4 py-2"><?php echo e($exam->examName); ?></td>
                    
                    <td class="border px-4 py-2"><?php echo e($exam->teacherPass); ?></td>
                    <td class="border px-4 py-2"><?php echo e($exam->studentPass); ?></td>
                    <td class="border px-4 py-2"><?php echo e($exam->examStart->format('Y-m-d H:i')); ?></td>
                    <td class="border px-4 py-2"><?php echo e($exam->duration); ?></td>
                    <td class="border px-4 py-2">
                        <!--[if BLOCK]><![endif]--><?php if(is_array($exam->questionsIds)): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $exam->questionsIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($qid); ?>,</span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <span class="text-gray-400 text-sm italic">No questions</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <td class="border px-4 py-2"><?php echo e($exam->comment ?? '-'); ?></td>
                    <td class="border px-4 py-2">
                        <button
                            wire:click="deleteExam(<?php echo e($exam->id); ?>)"
                            class="text-red-600 hover:underline"
                            onclick="return confirm('Are you sure you want to delete this exam?')"
                        >Delete</button>
                        <a href="<?php echo e(route('exam.edit', $exam->id)); ?>" class="text-blue-600 hover:underline"><?php echo e(__('Edit')); ?></a>
                        <a href="<?php echo e(route('exam.result', $exam->id)); ?>" class="text-blue-600 hover:underline"><?php echo e(__('Result')); ?></a>

                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div>

<script>
    document.getElementById('searchInput').addEventListener('input', function () {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll('#questionsTable tbody tr');

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
</script>
<?php /**PATH D:\Laravel\digital-evaluation-system\resources\views/livewire/exams/exam-index.blade.php ENDPATH**/ ?>