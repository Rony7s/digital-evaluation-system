<div id="clock" class="text-center text-3xl text-gray-600 dark:text-gray-300 space-y-4 p-4">
  <div class="uppercase tracking-wider text-3xl">SmartExam Platform</div>
  <div class="text-lg">An All-in-One System for Secure Exam Delivery, Automated Scoring, and Real-Time Performance Insights</div>
</div>
 
