<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 42" {{ $attributes }}>
    <image
        href="{{ asset('images/logo.jpg') }}"
        x="0" y="0" width="40" height="42" />
</svg>
